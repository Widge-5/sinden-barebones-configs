Fruit Shinobi User Guide:
Open the FruitShinobi.nes file in your favorite emulator or copy it onto a cart for use on the NES. Many emulators will allow the user to use the mouse to simulate the NES Zapper, however please make sure your emulator supports this feature. This game was created and tested using FCEUX. 

Begin playing by pulling the trigger. Each round will last until three fruits have not been sliced by the time they fall down again, or when the player attempts to slice a bomb. Coins will then be awarded based on how many points the player has earned, with 1 coin being given for each 8 points. 

These coins can then be used to buy different backgrounds. On the title screen use the left and right buttons on controller 1 to scroll between backgrounds. To buy a background press the A button. The game will not start if the player scrolls to a background they have not yet unlocked and pulls the zapper trigger. 

If you've read this far then you deserve a bonus, to unlock all the backgrounds change the six bytes from $6100 to $6105 to $FF.
